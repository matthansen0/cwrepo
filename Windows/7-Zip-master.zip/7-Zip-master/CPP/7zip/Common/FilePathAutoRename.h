// FilePathAutoRename.h

#ifndef ZIP7_INC_FILE_PATH_AUTO_RENAME_H
#define ZIP7_INC_FILE_PATH_AUTO_RENAME_H

#include "../../Common/MyString.h"

bool AutoRenamePath(FString &fullProcessedPath);

#endif
